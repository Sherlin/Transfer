// +build js

package x509

import "testing"

func TestSystemCertPool(t *testing.T) {
	t.Skip("no system roots")
}

func TestSystemRoots(t *testing.T) {
	t.Skip("no system roots")
}

func TestEnvVars(t *testing.T) {
	t.Skip("no system roots")
}

func TestSystemVerify(t *testing.T) {
	t.Skip("no system")
}

func TestImports(t *testing.T) {
	t.Skip("no system")
}
