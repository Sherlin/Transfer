// Copyright (c) 2016 Mattermost, Inc. All Rights Reserved.
// See License.txt for license information.

package main

import (

	"github.com/mattermost/mattermost-server/v5/model"
	log "github.com/sirupsen/logrus"

)



func CreateChannelIfPossible(channelName string) string {

	if _, error := GetChannelIdByName(channelName, botTeam.Id); error == "not found" {
	// Looks like we need to create the logging channel
		channel := &model.Channel{}
		channel.Name = channelName
		channel.DisplayName = "Say hello chat"
		channel.Purpose = "This is used as a test channel for saying hello smessages"
		channel.Type = model.CHANNEL_OPEN
		channel.TeamId = botTeam.Id
		if _, resp := client.CreateChannel(channel); resp.Error != nil {
			println("We failed to create the channel " + channelName)
			PrintError(resp.Error)
		} else {
			log.Info("Created Channel : " + channelName)
			return "Success creating channel"
		}
	} 
	
	return "Channel already exists"
	
}

func CreatePrivateChannelIfPossible(channelName string) (string, string) {

	if _, error := GetChannelIdByName(channelName, botTeam.Id); error == "not found" {
	// Looks like we need to create the logging channel
		channel := &model.Channel{}
		channel.Name = channelName
		channel.DisplayName = "Say hello chat"
		channel.Purpose = "This is used as a test channel for saying private messages"
		channel.Type = model.CHANNEL_PRIVATE 
		channel.TeamId = botTeam.Id
		if rchannel, resp := client.CreateChannel(channel); resp.Error != nil {
			println("We failed to create the channel " + channelName)
			PrintError(resp.Error)
			return "", "Error creating private channel"
		} else {
			log.Info("Created Channel : " + channelName)
			return rchannel.Id,"Success creating private channel"
		}
	} 
	
	return "","Channel already exists"
	
}

func CreateTeamIfPossible(TeamName string) (string , string){

	if _, error := GetTeamIdByName(TeamName); error == "not found" {
	// Looks like we need to create the logging channel
		team := &model.Team{}
		team.Name = TeamName
		team.DisplayName = "Time to take a break"
		team.Description = "This is used as a test channel for saying hello smessages"
		team.Type = model.TEAM_OPEN
		//team.TeamId = botTeam.Id
		if rteam, resp := client.CreateTeam(team); resp.Error != nil {

			log.Warn(resp.Error)
			return "", "Error creating team"
		} else {

			log.Info("Created Team : " + TeamName)
			return rteam.Id, "Success creating team"
		}
	}
	return "","Team already exists"
}

func DeleteChannelIfPossible(channelName string) string {

	
	if channelId, error := GetChannelIdByName(channelName, botTeam.Id); error != "not found" {

		if _, resp := client.DeleteChannel(channelId); resp.Error != nil {
			log.Warn(resp.Error)	
			return "Error deleting channel"	
		} else {
			log.Info("Deleted Channel : " + channelName)
			return "Success deleting channel"
		}
	} 

	return "Channel not found" 
	
	
}
func DeleteTeamIfPossible(teamName string) string {

	if teamId, error := GetTeamIdByName(teamName); error != "not found" {
	
		if _, resp := client.PermanentDeleteTeam(teamId); resp.Error != nil {
			log.Warn(resp.Error)
			return "Error deleting team" 			
		} else {
			log.Info("Deleted Team : " + teamName)
			return "Success deleting team" 
		}
	}
	return "Team not found" 
	
}

func GetTeamIdByName(teamName string)(string, string){
	if rteam, resp := client.GetTeamByName(teamName,  ""); resp.Error != nil {
		log.Warn("We failed to get the team")
		log.Warn(resp.Error)
		return "" ,"not found"
	} else {
		return rteam.Id, ""
	}
}
func GetChannelIdByName(channelName string, teamId string)(string, string){
	if rchannel, resp := client.GetChannelByName(channelName, teamId , "true"); resp.Error != nil {
		log.WithFields(log.Fields{ "channelName": channelName, "teamId":teamId}).Warn("We failed to get the channels" )
		log.Warn(resp.Error)
		log.Warn(resp)
		return "" ,"not found"
	} else {
		println("rchannel id : " +  rchannel.Id)
		return rchannel.Id, ""
	}
}

func AddMemberToTeam(teamId string , UserID string){

	log.WithFields(log.Fields{ "username": teamId, "id":UserID }).Info("Adding member to Team")
	users, _ := client.GetUsersByUsernames([]string{UserID})

	client.AddTeamMember(teamId, users[0].Id)

	log.WithFields(log.Fields{ "username": users[0].Username, "user_id":users[0].Id,"team_id":teamId}).Info("User added into the team");
}

func AddMemberToChannel(channelId string , UserID string){

	log.WithFields(log.Fields{ "username": channelId, "id":UserID }).Info("Adding member to Channel")
	users, _ := client.GetUsersByUsernames([]string{UserID})
	client.AddChannelMember(channelId, users[0].Id)
	/*
	if channelMember, resp :=client.AddChannelMember(channelId, users[0].Id); resp.Error !=nil{
	log.WithFields(log.Fields{ "username": users[0].Username, "user_id":users[0].Id,"channel_id":channelId}).Info("error adding user to channel ")
	
	}*/
	log.WithFields(log.Fields{ "username": users[0].Username, "user_id":users[0].Id,"channel_id":channelId}).Info("User added into the channel");
}




