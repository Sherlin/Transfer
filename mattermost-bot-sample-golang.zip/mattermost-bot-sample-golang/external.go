package main

import (

	"net/http"
	"io/ioutil"
	log "github.com/sirupsen/logrus"

)

func CallWeatherAPI(postID string) {

	log.Info("Calling weather API" )

	url := "https://community-open-weather-map.p.rapidapi.com/weather?callback=test&id=2172797&units=%2522metric%2522%20or%20%2522imperial%2522&mode=xml%252C%20html&q=Singapore"

	req, _ := http.NewRequest("GET", url, nil)

	req.Header.Add("x-rapidapi-host", "community-open-weather-map.p.rapidapi.com")
	req.Header.Add("x-rapidapi-key", "9fdcda42b4mshfcf2e1b168d750bp137004jsn7522056c40c1")

	res, _ := http.DefaultClient.Do(req)

	defer res.Body.Close()
	body, _ := ioutil.ReadAll(res.Body)

	println(res)
	println(string(body))
	SendMsgToDebuggingChannel(string(body), postID)
}