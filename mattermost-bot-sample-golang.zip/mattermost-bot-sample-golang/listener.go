package main

import (

	"regexp"
	"github.com/mattermost/mattermost-server/v5/model"
	"strings"
	log "github.com/sirupsen/logrus"

)
func HandleMsgFromDebuggingChannel(event *model.WebSocketEvent) {
	// If this isn't the debugging channel then lets ingore it
	if event.Broadcast.ChannelId != debuggingChannel.Id {
		return
	}

	// Lets only reponded to messaged posted events
	if event.Event != model.WEBSOCKET_EVENT_POSTED {
		return
	}

	println("responding to debugging channel msg")

	post := model.PostFromJson(strings.NewReader(event.Data["post"].(string)))
	if post != nil {

		// ignore my events
		if post.UserId == botUser.Id {
			return
		}

		// if you see any word matching 'alive' then respond
		if matched, _ := regexp.MatchString(`(?:^|\W)alive(?:$|\W)`, post.Message); matched {
			SendMsgToDebuggingChannel("Yes I'm running", post.Id)
			return
		}

		// if you see any word matching 'up' then respond
		if matched, _ := regexp.MatchString(`(?:^|\W)up(?:$|\W)`, post.Message); matched {
			SendMsgToDebuggingChannel("Yes I'm running", post.Id)
			return
		}

		// if you see any word matching 'running' then respond
		if matched, _ := regexp.MatchString(`(?:^|\W)running(?:$|\W)`, post.Message); matched {
			SendMsgToDebuggingChannel("Yes I'm running", post.Id)
			return
		}

		// if you see any word matching 'hello' then respond
		if matched, _ := regexp.MatchString(`(?:^|\W)hello(?:$|\W)`, post.Message); matched {
			SendMsgToDebuggingChannel("Yes I'm running", post.Id)
			return
		}
		if matched, _ := regexp.MatchString(`(?:^|\W)createPrivate(?:$|\W)`, post.Message); matched {
			channelId, status := CreatePrivateChannelIfPossible("private-chat")
			log.Info("Adding MembersToChannel : " + channelId)
			if(channelId != ""  ) {
				log.Info("Adding MembersToChannel")
				AddMemberToChannel(channelId  , "test_user1" )
				AddMemberToChannel(channelId  , "test_user2" )
			}
			SendMsgToDebuggingChannel(status, post.Id)

			return
		}
		if matched, _ := regexp.MatchString(`(?:^|\W)create(?:$|\W)`, post.Message); matched {
			status:= CreateChannelIfPossible("say-hello-chat")
			SendMsgToDebuggingChannel(status, post.Id)
			
				
			return
		}

		if matched, _ := regexp.MatchString(`(?:^|\W)delete(?:$|\W)`, post.Message); matched {
			status:= DeleteChannelIfPossible("say-hello-chat")
			SendMsgToDebuggingChannel(status, post.Id)
			return
		}	
		
		if matched, _ := regexp.MatchString(`(?:^|\W)weather(?:$|\W)`, post.Message); matched {
			CallWeatherAPI( post.Id)
			SendMsgToDebuggingChannel("Callling the weather", post.Id)
			return
		}
		if matched, _ := regexp.MatchString(`(?:^|\W)createteam(?:$|\W)`, post.Message); matched {
			teamId, status := CreateTeamIfPossible("coffeebreak123")
			if(strings.Contains(status, "Success")  ) {
				AddMemberToTeam(teamId, "alexngng")
			} 
			
			SendMsgToDebuggingChannel(status, post.Id)
			log.Info("creating a team")
			return
		}	
		if matched, _ := regexp.MatchString(`(?:^|\W)deleteteam(?:$|\W)`, post.Message); matched {
			status:= DeleteTeamIfPossible("coffeebreak123")
			SendMsgToDebuggingChannel(status, post.Id)
			return
		}							
	}

	//SendMsgToDebuggingChannel("I did not understand you!", post.Id)
}
