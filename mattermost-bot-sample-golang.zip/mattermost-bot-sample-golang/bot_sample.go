// Copyright (c) 2016 Mattermost, Inc. All Rights Reserved.
// See License.txt for license information.

package main

import (
//	"os"
//	"os/signal"
//	"regexp"
//	"strings"
//	"net/http"
//	"io/ioutil"
	log "github.com/sirupsen/logrus"
	"github.com/mattermost/mattermost-server/v5/model"
	"os"
	"time"
)




const (
	SAMPLE_NAME = "Mattermost Bot Sample"

	USER_EMAIL    = "bot@example.com"
	USER_PASSWORD = "Password123%"
	USER_NAME     = "samplebot"
	USER_FIRST    = "Sample"
	USER_LAST     = "Bot"

	TEAM_NAME        = "botsample"
	CHANNEL_LOG_NAME = "debugging-for-sample-bot"
	LOG_DIRECTORY ="/root/mage/mattermost-bot-sample-golang/logs/"

)

var client *model.Client4
var webSocketClient *model.WebSocketClient

var botUser *model.User
var botTeam *model.Team
var debuggingChannel *model.Channel

// Documentation for the Go driver can be found
// at https://godoc.org/github.com/mattermost/platform/model#Client
func main() {
	println(SAMPLE_NAME)

	SetupGracefulShutdown(SAMPLE_NAME)

	client = model.NewAPIv4Client("http://localhost:8065")

	// Lets test to see if the mattermost server is up and running
	MakeSureServerIsRunning()

	RunBot()
	//var log =log.New()
	currentTime := time.Now()
	var filename string = LOG_DIRECTORY+ "logfile_"+currentTime.Format("2006-01-02")  + ".log"

    // Create the log file if doesn't exist. And append to it if it already exists.
    f, err123 := os.OpenFile(filename, os.O_WRONLY | os.O_APPEND | os.O_CREATE, 0644)
    Formatter := new(log.TextFormatter)
    Formatter.TimestampFormat = "2006-01-20 15:04:05"
    Formatter.FullTimestamp = true
    log.SetFormatter(Formatter)
    if err123 != nil {
        // Cannot open log file. Logging to stderr
        println(err123)
    }else{
        log.SetOutput(f)
	}


    log.Info("Some info. Earth is not flat")
    log.Warning("This is a warning")
    log.Error("Not fatal. An error. Won't stop execution")

	// This is an important step.  Lets make sure we use the botTeam
	// for all future web service requests that require a team.
	//client.SetTeamId(botTeam.Id)

	// Lets create a bot channel for logging debug messages into
	CreateBotDebuggingChannelIfNeeded()
	SendMsgToDebuggingChannel("_"+SAMPLE_NAME+" has **started** running_", "")

	// Lets start listening to some channels via the websocket!
	webSocketClient, err := model.NewWebSocketClient4("ws://localhost:8065", client.AuthToken)
	if err != nil {
		println("We failed to connect to the web socket")
		PrintError(err)
	}

	webSocketClient.Listen()

	go func() {
		for {
			select {
			case resp := <-webSocketClient.EventChannel:
				HandleWebSocketResponse(resp)
			}
		}
	}()

	// You can block forever with
	select {}
}
func RunBot() {
	// lets attempt to login to the Mattermost server as the bot user
	// This will set the token required for all future calls
	// You can get this token with client.AuthToken
	LoginAsTheBotUser()

	// If the bot user doesn't have the correct information lets update his profile
	UpdateTheBotUserIfNeeded()

	// Lets find our bot team
	FindBotTeam()
}